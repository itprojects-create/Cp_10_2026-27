import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';

class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();
  UserModel? _user;
  bool _isLoading = false;
  String? _errorMessage;
  bool _isGuest = false;

  UserModel? get user => _user;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get isGuest => _isGuest;

  AuthProvider() {
    _authService.user.listen((User? firebaseUser) async {
      if (firebaseUser != null) {
        final userData = await _authService.getUserData(firebaseUser.uid);
        if (userData != null) {
          _user = UserModel.fromMap(userData);
        } else {
          // Fallback if firestore document doesn't exist yet
          _user = UserModel(
            uid: firebaseUser.uid,
            name: firebaseUser.displayName ?? 'Farmer',
            email: firebaseUser.email ?? '',
          );
        }
      } else {
        _user = null;
      }
      notifyListeners();
    });
  }

  Future<bool> login(String email, String password) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();
    try {
      User? firebaseUser = await _authService.login(email, password);
      if (firebaseUser != null) {
        final userData = await _authService.getUserData(firebaseUser.uid);
        if (userData != null) {
          _user = UserModel.fromMap(userData);
        }
      }
      _isLoading = false;
      notifyListeners();
      return _user != null;
    } catch (e) {
      _errorMessage = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> register(String name, String email, String password) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();
    try {
      User? firebaseUser = await _authService.register(name, email, password);
      if (firebaseUser != null) {
        _user = UserModel(uid: firebaseUser.uid, name: name, email: email);
      }
      _isLoading = false;
      notifyListeners();
      return _user != null;
    } catch (e) {
      _errorMessage = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> logout() async {
    await _authService.logout();
    _user = null;
    _isGuest = false;
    notifyListeners();
  }

  void skipLogin() {
    _isGuest = true;
    notifyListeners();
  }
}
