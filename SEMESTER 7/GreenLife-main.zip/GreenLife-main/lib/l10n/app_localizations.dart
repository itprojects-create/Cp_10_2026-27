import 'package:flutter/material.dart';

class AppLocalizations {
  final Locale locale;

  AppLocalizations(this.locale);

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  static final Map<String, Map<String, String>> _localizedValues = {
    'en': {
      'profile': 'Profile',
      'editProfile': 'Edit Profile',
      'languageSettings': 'Language Settings',
      'notifications': 'Notifications',
      'privacySecurity': 'Privacy & Security',
      'helpSupport': 'Help & Support',
      'logout': 'Logout',
      'guestUser': 'Guest User',
      'noEmailLinked': 'No email linked',
      'areYouSureLogout': 'Are you sure you want to logout?',
      'yes': 'Yes',
      'cancel': 'Cancel',
      'welcomeBack': 'Welcome Back!',
      'signInToAccount': 'Sign in to your GreenLife account',
      'email': 'Email',
      'password': 'Password',
      'login': 'Login',
      'dontHaveAccount': 'Don\'t have an account?',
      'register': 'Register',
      'skipForNow': 'Skip for now',
      'createAccount': 'Create Account',
      'startGreenJourney': 'Start your green journey today',
      'fullName': 'Full Name',
      'confirmPassword': 'Confirm Password',
      'diseaseDetection': 'Disease Detection',
      'fertilizerPredictor': 'Fertilizer Predictor',
      'aiTools': 'AI Tools',
      'takePhoto': 'Take a photo to identify pests or diseases.',
      'aiDrivenAdvice': 'AI-driven advice based on crop and soil.',
    },
    'hi': {
      'profile': 'प्रोफ़ाइल',
      'editProfile': 'प्रोफ़ाइल संपादित करें',
      'languageSettings': 'भाषा सेटिंग्स',
      'notifications': 'सूचनाएं',
      'privacySecurity': 'गोपनीयता और सुरक्षा',
      'helpSupport': 'सहायता और समर्थन',
      'logout': 'लॉग आउट',
      'guestUser': 'अतिथि उपयोगकर्ता',
      'noEmailLinked': 'कोई ईमेल लिंक नहीं है',
      'areYouSureLogout': 'क्या आप वाकई लॉग आउट करना चाहते हैं?',
      'yes': 'हाँ',
      'cancel': 'रद्द करें',
      'welcomeBack': 'वापसी पर स्वागत है!',
      'signInToAccount': 'अपने GreenLife खाते में साइन इन करें',
      'email': 'ईमेल',
      'password': 'पासवर्ड',
      'login': 'लॉग इन',
      'dontHaveAccount': 'क्या आपके पास खाता नहीं है?',
      'register': 'रजिस्टर करें',
      'skipForNow': 'अभी के लिए छोड़ दें',
      'createAccount': 'खाता बनाएँ',
      'startGreenJourney': 'आज ही अपनी हरित यात्रा शुरू करें',
      'fullName': 'पूरा नाम',
      'confirmPassword': 'पासवर्ड की पुष्टि करें',
      'diseaseDetection': 'रोग का पता लगाना',
      'fertilizerPredictor': 'उर्वरक कैलकुलेटर',
      'aiTools': 'AI उपकरण',
      'takePhoto': 'कीटों या बीमारियों की पहचान करने के लिए एक फोटो लें।',
      'aiDrivenAdvice': 'फसल और मिट्टी के आधार पर AI सलाह।',
    },
    'mr': {
      'profile': 'प्रोफाइल',
      'editProfile': 'प्रोफाइल संपादित करा',
      'languageSettings': 'भाषा सेटिंग्ज',
      'notifications': 'सूचना',
      'privacySecurity': 'गोपनीयता आणि सुरक्षा',
      'helpSupport': 'मदत आणि समर्थन',
      'logout': 'लॉगआउट',
      'guestUser': 'अतिथी वापरकर्ता',
      'noEmailLinked': 'कोणताही ईमेल लिंक केलेला नाही',
      'areYouSureLogout': 'तुम्हाला नक्की लॉगआउट करायचे आहे का?',
      'yes': 'होय',
      'cancel': 'रद्द करा',
      'welcomeBack': 'पुन्हा स्वागत आहे!',
      'signInToAccount': 'तुमच्या GreenLife अकाउंटमध्ये साइन इन करा',
      'email': 'ईमेल',
      'password': 'पासवर्ड',
      'login': 'लॉगिन',
      'dontHaveAccount': 'अकाउंट नाही का?',
      'register': 'नोंदणी करा',
      'skipForNow': 'आतासाठी वगळा',
      'createAccount': 'अकाउंट तयार करा',
      'startGreenJourney': 'आजच तुमचा हरित प्रवास सुरू करा',
      'fullName': 'पूर्ण नाव',
      'confirmPassword': 'पासवर्डची पुष्टी करा',
      'diseaseDetection': 'रोग ओळख',
      'fertilizerPredictor': 'खत कॅल्क्युलेटर',
      'aiTools': 'AI साधने',
      'takePhoto': 'कीटक किंवा रोग ओळखण्यासाठी फोटो काढा.',
      'aiDrivenAdvice': 'पीक आणि मातीवर आधारित AI सल्ला.',
    }
  };

  String getTranslate(String key) {
    return _localizedValues[locale.languageCode]?[key] ?? _localizedValues['en']?[key] ?? key;
  }
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => ['en', 'hi', 'mr'].contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async {
    return AppLocalizations(locale);
  }

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

// Extension for easier usage
extension TranslateExtension on BuildContext {
  String t(String key) => AppLocalizations.of(this)?.getTranslate(key) ?? key;
}
