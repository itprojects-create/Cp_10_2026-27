import 'package:flutter/material.dart';

class CultivationTipsScreen extends StatelessWidget {
  const CultivationTipsScreen({super.key});

  final List<Map<String, dynamic>> _crops = const [
    {
      'name': 'Cotton',
      'icon': '🌿',
      'soil': 'Well-drained black soil or alluvial soil.',
      'watering': 'Requires 500-1100 mm of rainfall during the growing season.',
      'fertilizer': 'Nitrogen, Phosphorus, and Potassium (NPK) in 2:1:1 ratio.',
      'harvesting': 'Harvest when bolls are fully opened and fluffy.',
    },
    {
      'name': 'Soybean',
      'icon': '🌱',
      'soil': 'Fertile, well-drained loamy soil.',
      'watering': 'Needs steady moisture, especially during flowering and pod development.',
      'fertilizer': 'Primarily needs Phosphorus and Potassium; Nitrogen fixing crop.',
      'harvesting': 'Harvest when pods are dry and rattle when shaken.',
    },
    {
      'name': 'Sugarcane',
      'icon': '🎋',
      'soil': 'Deep, well-drained rich loamy soil.',
      'watering': 'High water requirement; regular irrigation needed.',
      'fertilizer': 'High Nitrogen requirement (150-250 kg/ha).',
      'harvesting': 'Harvest when juice brix reaches 18-20%.',
    },
    {
      'name': 'Wheat',
      'icon': '🌾',
      'soil': 'Well-drained fertile loamy soil.',
      'watering': 'Requires 4-6 irrigations at critical growth stages.',
      'fertilizer': 'Standard NPK 4:2:1 ratio.',
      'harvesting': 'Harvest when grains are hard and straw is dry and brittle.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cultivation Tips')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _crops.length,
        itemBuilder: (context, index) {
          final crop = _crops[index];
          return Card(
            child: ExpansionTile(
              leading: Text(crop['icon'], style: const TextStyle(fontSize: 32)),
              title: Text(crop['name'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildTipRow(Icons.landscape_outlined, 'Soil', crop['soil']),
                      _buildTipRow(Icons.water_drop_outlined, 'Watering', crop['watering']),
                      _buildTipRow(Icons.science_outlined, 'Fertilizer', crop['fertilizer']),
                      _buildTipRow(Icons.agriculture_outlined, 'Harvesting', crop['harvesting']),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildTipRow(IconData icon, String title, String content) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: Colors.green[700]),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                const SizedBox(height: 2),
                Text(content, style: const TextStyle(fontSize: 14)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
