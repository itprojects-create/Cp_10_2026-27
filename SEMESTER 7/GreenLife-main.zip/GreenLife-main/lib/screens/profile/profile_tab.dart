import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/locale_provider.dart';
import '../../l10n/app_localizations.dart';

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final user = authProvider.user;

    return Scaffold(
      appBar: AppBar(title: Text(context.t('profile'))),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 40),
            Center(
              child: Stack(
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundColor: Colors.green[100],
                    child: const Icon(Icons.person, size: 80, color: Colors.green),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: CircleAvatar(
                      backgroundColor: Theme.of(context).primaryColor,
                      radius: 18,
                      child: const Icon(Icons.edit, size: 18, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Text(user?.name ?? context.t('guestUser'), style: Theme.of(context).textTheme.headlineMedium),
            Text(user?.email ?? context.t('noEmailLinked'), style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 40),
            const Divider(),
            _buildProfileOption(Icons.edit_outlined, context.t('editProfile'), () {}),
            _buildProfileOption(Icons.language_outlined, context.t('languageSettings'), () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: Text(context.t('languageSettings')),
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ListTile(title: const Text('English'), onTap: () { Provider.of<LocaleProvider>(context, listen: false).setLocale(const Locale('en')); Navigator.pop(context); }),
                      ListTile(title: const Text('हिन्दी'), onTap: () { Provider.of<LocaleProvider>(context, listen: false).setLocale(const Locale('hi')); Navigator.pop(context); }),
                      ListTile(title: const Text('मराठी'), onTap: () { Provider.of<LocaleProvider>(context, listen: false).setLocale(const Locale('mr')); Navigator.pop(context); }),
                    ],
                  ),
                ),
              );
            }),
            _buildProfileOption(Icons.notifications_outlined, context.t('notifications'), () {}),
            _buildProfileOption(Icons.security_outlined, context.t('privacySecurity'), () {}),
            _buildProfileOption(Icons.help_outline, context.t('helpSupport'), () {}),
            const Divider(),
            const SizedBox(height: 8),
            _buildProfileOption(Icons.logout, context.t('logout'), () async {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  content: Text(context.t('areYouSureLogout')),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: Text(context.t('cancel'))),
                    TextButton(
                      onPressed: () async {
                        Navigator.pop(context);
                        await authProvider.logout();
                      },
                      child: Text(context.t('yes'), style: const TextStyle(color: Colors.red)),
                    ),
                  ],
                ),
              );
            }, color: Colors.red),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileOption(IconData icon, String title, VoidCallback onTap, {Color? color}) {
    return ListTile(
      leading: Icon(icon, color: color ?? Colors.green[800]),
      title: Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w500)),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: onTap,
    );
  }
}
