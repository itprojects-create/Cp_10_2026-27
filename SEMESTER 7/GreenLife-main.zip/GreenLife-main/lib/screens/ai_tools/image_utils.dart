import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;

Float32List preprocessImage(File file) {
  img.Image? image = img.decodeImage(file.readAsBytesSync());

  img.Image resized = img.copyResize(image!, width: 224, height: 224);

  var input = Float32List(1 * 224 * 224 * 3);

  int index = 0;

  for (int y = 0; y < 224; y++) {
    for (int x = 0; x < 224; x++) {
      final pixel = resized.getPixel(x, y);

      input[index++] = pixel.r / 255.0;
      input[index++] = pixel.g / 255.0;
      input[index++] = pixel.b / 255.0;
    }
  }

  return input;
}
