import 'dart:typed_data';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:flutter/services.dart';

class TFLiteHelper {
  Interpreter? interpreter;
  List<String> labels = [];

  // ==========================
  // LOAD MODEL
  // ==========================
  Future<void> loadModel() async {
    interpreter = await Interpreter.fromAsset('assets/model.tflite');

    labels = await _loadLabels();
  }

  // ==========================
  // LOAD LABELS
  // ==========================
  Future<List<String>> _loadLabels() async {
    final data = await rootBundle.loadString('assets/labels.txt');

    return data.split('\n').where((label) => label.trim().isNotEmpty).toList();
  }

  // ==========================
  // PREDICT
  // ==========================
  List<double> predict(Float32List input) {
    // reshape input
    final inputReshaped = input.reshape([1, 224, 224, 3]);

    // create output buffer (DOUBLE)
    final output = List.generate(
      1,
      (index) => List.filled(labels.length, 0.0),
    );

    interpreter!.run(inputReshaped, output);

    return output[0];
  }
}
