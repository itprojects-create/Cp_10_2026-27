import 'package:flutter/material.dart';

class FertilizerCalculatorScreen extends StatefulWidget {
  const FertilizerCalculatorScreen({super.key});

  @override
  State<FertilizerCalculatorScreen> createState() => _FertilizerCalculatorScreenState();
}

class _FertilizerCalculatorScreenState extends State<FertilizerCalculatorScreen> {
  String? _selectedCrop;
  String? _selectedSoil;
  String _areaUnit = 'Acre';
  final _areaController = TextEditingController();
  String? _recommendation;

  final List<String> _crops = ['Cotton', 'Soybean', 'Sugarcane', 'Wheat', 'Maize'];
  final List<String> _soils = ['Black Soil', 'Loamy Soil', 'Sandy Soil', 'Alluvial Soil'];

  void _calculate() {
    if (_selectedCrop == null || _selectedSoil == null || _areaController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all fields')),
      );
      return;
    }

    double area = double.tryParse(_areaController.text) ?? 0;
    if (area <= 0) return;
    
    // Convert to acres for standard calculation (1 Hectare ≈ 2.47 Acres)
    double areaInAcres = _areaUnit == 'Hectare' ? area * 2.47 : area;

    // Simple mock agriculture logic
    setState(() {
      double urea = areaInAcres * 50;
      double dap = areaInAcres * 30;
      double mop = areaInAcres * 20;

      _recommendation = "For $area $_areaUnit of $_selectedCrop in $_selectedSoil:\n\n"
          "• Urea: ${urea.toStringAsFixed(1)} kg\n"
          "• DAP: ${dap.toStringAsFixed(1)} kg\n"
          "• MOP: ${mop.toStringAsFixed(1)} kg\n\n"
          "Note: Apply Urea in three split doses for better results.";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Fertilizer Calculator')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(labelText: 'Select Crop', prefixIcon: Icon(Icons.grass)),
              value: _selectedCrop,
              items: _crops.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
              onChanged: (v) => setState(() => _selectedCrop = v),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(labelText: 'Soil Type', prefixIcon: Icon(Icons.landscape)),
              value: _selectedSoil,
              items: _soils.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
              onChanged: (v) => setState(() => _selectedSoil = v),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  flex: 2,
                  child: TextFormField(
                    controller: _areaController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Land Area',
                      prefixIcon: Icon(Icons.square_foot),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  flex: 1,
                  child: DropdownButtonFormField<String>(
                    decoration: const InputDecoration(labelText: 'Unit'),
                    value: _areaUnit,
                    items: ['Acre', 'Hectare'].map((u) => DropdownMenuItem(value: u, child: Text(u))).toList(),
                    onChanged: (v) => setState(() => _areaUnit = v!),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: _calculate,
              child: const Text('Calculate Recommendation'),
            ),
            if (_recommendation != null) ...[
              const SizedBox(height: 32),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.green[50],
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.green[200]!),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.tips_and_updates, color: Colors.green),
                        SizedBox(width: 8),
                        Text('AI Recommendation', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text(_recommendation!, style: const TextStyle(fontSize: 16, height: 1.5)),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
