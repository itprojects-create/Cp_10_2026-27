import 'package:flutter/material.dart';
import 'disease_detection_screen.dart';
import 'fertilizer_calculator_screen.dart';
import '../../l10n/app_localizations.dart';

class AIToolsTab extends StatelessWidget {
  const AIToolsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.t('aiTools'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildToolCard(
            context,
            context.t('diseaseDetection'),
            context.t('takePhoto'),
            Icons.center_focus_weak,
            const DiseaseDetectionScreen(),
          ),
          const SizedBox(height: 16),
          _buildToolCard(
            context,
            context.t('fertilizerPredictor'),
            context.t('aiDrivenAdvice'),
            Icons.precision_manufacturing_outlined,
            const FertilizerCalculatorScreen(),
          ),
          const SizedBox(height: 16),
          _buildToolCard(
            context,
            'Yield Estimator (Coming Soon)',
            'Predict your harvest weight.',
            Icons.trending_up,
            null,
          ),
        ],
      ),
    );
  }

  Widget _buildToolCard(BuildContext context, String title, String subtitle, IconData icon, Widget? screen) {
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.all(20),
        leading: Icon(icon, size: 40, color: Colors.green[700]),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        subtitle: Text(subtitle),
        onTap: screen != null ? () => Navigator.push(context, MaterialPageRoute(builder: (context) => screen)) : null,
      ),
    );
  }
}
