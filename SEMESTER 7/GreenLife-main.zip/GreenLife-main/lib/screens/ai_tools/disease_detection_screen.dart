import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

// AI helpers
import '../ai_tools/tflite_helper.dart';
import '../ai_tools/image_utils.dart';

class DiseaseDetectionScreen extends StatefulWidget {
  const DiseaseDetectionScreen({super.key});

  @override
  State<DiseaseDetectionScreen> createState() => _DiseaseDetectionScreenState();
}

class _DiseaseDetectionScreenState extends State<DiseaseDetectionScreen> {
  File? _image;
  bool _isLoading = false;
  Map<String, dynamic>? _result;

  final ImagePicker _picker = ImagePicker();
  final TFLiteHelper _tflite = TFLiteHelper();

  @override
  void initState() {
    super.initState();
    _tflite.loadModel();
  }

  Future<void> _pickImage(ImageSource source) async {
    final XFile? selected = await _picker.pickImage(source: source);
    if (selected != null) {
      setState(() {
        _image = File(selected.path);
        _result = null;
      });
    }
  }

  // ==========================
  // 🔥 REAL MODEL INFERENCE
  // ==========================
  Future<void> _analyzeImage() async {
    if (_image == null) return;

    if (_tflite.interpreter == null) {
      debugPrint("Model not loaded yet!");
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final input = preprocessImage(_image!);
      final output = _tflite.predict(input);

      int maxIndex = 0;
      double maxValue = output[0];

      for (int i = 1; i < output.length; i++) {
        if (output[i] > maxValue) {
          maxValue = output[i];
          maxIndex = i;
        }
      }

      final rawLabel = _tflite.labels[maxIndex];
      final disease = _cleanLabel(rawLabel);

      setState(() {
        _result = {
          'disease': disease,
          'confidence': maxValue,
          'description': _getDescription(disease),
          'treatment': _getTreatment(disease),
          'recoverable': _isRecoverable(disease),
        };
      });
    } catch (e) {
      debugPrint("ERROR: $e");
    }

    setState(() {
      _isLoading = false;
    });
  }

  // ==========================
  // 🔧 HELPERS
  // ==========================
  String _cleanLabel(String raw) {
    return raw
        .replaceAll('___', ' ')
        .replaceAll('__', ' ')
        .replaceAll('_', ' ')
        .trim();
  }

  String _getDescription(String disease) {
    if (disease.contains('Early blight')) {
      return 'Fungal disease causing dark spots with rings on leaves.';
    } else if (disease.contains('Late blight')) {
      return 'Serious disease causing rapid decay of leaves.';
    } else if (disease.contains('Bacterial spot')) {
      return 'Bacterial infection causing small dark spots.';
    } else if (disease.contains('Leaf Mold')) {
      return 'Fungal growth due to humidity.';
    } else if (disease.contains('healthy')) {
      return 'Plant is healthy.';
    } else {
      return 'Disease detected. Further inspection needed.';
    }
  }

  String _getTreatment(String disease) {
    if (disease.contains('Early blight')) {
      return 'Apply fungicide and remove infected leaves.';
    } else if (disease.contains('Late blight')) {
      return 'Use copper fungicide and avoid excess moisture.';
    } else if (disease.contains('Bacterial spot')) {
      return 'Use copper sprays and resistant seeds.';
    } else if (disease.contains('Leaf Mold')) {
      return 'Improve ventilation and apply fungicide.';
    } else if (disease.contains('healthy')) {
      return 'No treatment required.';
    } else {
      return 'Consult agricultural expert.';
    }
  }

  bool _isRecoverable(String disease) {
    return !disease.contains('Late blight');
  }

  // ==========================
  // UI (UNCHANGED)
  // ==========================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Disease Detection')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 250,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(16),
                image: _image != null
                    ? DecorationImage(
                        image: FileImage(_image!), fit: BoxFit.cover)
                    : null,
              ),
              child: _image == null
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.image_outlined,
                            size: 64, color: Colors.grey[400]),
                        const SizedBox(height: 16),
                        const Text('Select a photo to diagnose'),
                      ],
                    )
                  : null,
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickImage(ImageSource.camera),
                    icon: const Icon(Icons.camera_alt_outlined),
                    label: const Text('Camera'),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickImage(ImageSource.gallery),
                    icon: const Icon(Icons.photo_library_outlined),
                    label: const Text('Gallery'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            if (_image != null && _result == null)
              ElevatedButton(
                onPressed: _isLoading ? null : _analyzeImage,
                child: _isLoading
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                            color: Colors.white, strokeWidth: 2))
                    : const Text('Analyze Image'),
              ),
            if (_result != null) ...[
              const Divider(height: 48),
              Text(
                'Result: ${_result!['disease']}',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              const SizedBox(height: 8),
              Text(
                'Confidence: ${(_result!['confidence'] * 100).toStringAsFixed(1)}%',
                style: const TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.blue),
              ),
              const SizedBox(height: 8),
              Text(
                _result!['recoverable']
                    ? 'Recovery Possible ✅'
                    : 'Recovery Difficult ❌',
                style: TextStyle(
                  color: _result!['recoverable'] ? Colors.green : Colors.red,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 24),
              _buildSection('Description', _result!['description']),
              const SizedBox(height: 16),
              _buildSection('Treatment Suggestions', _result!['treatment']),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSection(String title, String content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(content),
      ],
    );
  }
}
