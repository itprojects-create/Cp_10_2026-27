import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  /// Save user data to Firestore after registration
  Future<void> saveUser(String uid, String email, String name) async {
    try {
      await _db.collection('users').doc(uid).set({
        'uid': uid,
        'email': email,
        'name': name,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print('Error saving user: $e');
      rethrow;
    }
  }

  /// Add a new post to the community forum
  Future<void> addPost(String uid, String userName, String text, String? imageUrl) async {
    try {
      await _db.collection('posts').add({
        'uid': uid,
        'userName': userName,
        'text': text,
        'imageUrl': imageUrl,
        'likes': [],
        'timestamp': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print('Error adding post: $e');
      rethrow;
    }
  }

  /// Get real-time stream of posts ordered by timestamp
  Stream<QuerySnapshot> getPosts() {
    return _db
        .collection('posts')
        .orderBy('timestamp', descending: true)
        .snapshots();
  }
}
