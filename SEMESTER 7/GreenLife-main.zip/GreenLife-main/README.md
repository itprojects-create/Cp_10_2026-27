# GreenLife Flutter App Setup Guide

This guide will help you set up and run the "GreenLife" application.

## Prerequisites
- Flutter SDK (latest stable)
- Firebase Account
- Android Studio / VS Code with Flutter extension

## Project Structure
```text
lib/
  ├── models/      # Data models (User, Post)
  ├── providers/   # State management (Auth)
  ├── screens/     # UI Screens (Auth, Home, AI Tools, Community, Profile)
  ├── services/    # Firebase & AI logic
  ├── utils/       # Theme and constants
  └── widgets/     # Reusable components
```

## Firebase Setup (Mandatory)
Since this app uses Firebase Authentication, Firestore, and Storage, you must link it to your own Firebase project:

1. **Create a Firebase Project**: Go to [Firebase Console](https://console.firebase.google.com/).
2. **Add Android App**:
   - Register your app with package name (likely `com.example.green_life`).
   - Download `google-services.json` and place it in `android/app/`.
3. **Add iOS App**:
   - Register and download `GoogleService-Info.plist` and place it in `ios/Runner/` via Xcode.
4. **Enable Services**:
   - **Authentication**: Enable Email/Password provider.
   - **Cloud Firestore**: Start in "Test Mode" or define rules.
   - **Firebase Storage**: Enable for image uploads.
5. **Firestore Rules**:
   Ensure basic read/write permissions for authenticated users.

## How to Run
1. Open terminal in the project directory:
   ```bash
   flutter pub get
   ```
2. Connect your device or start an emulator.
3. Run the app:
   ```bash
   flutter run
   ```

## Key Features
- **Clean Green UI**: Modern Material 3 design with nature-inspired colors.
- **AI Tools**: Mock implementations for Disease Detection and Fertilizer recommendation.
- **Realtime Community**: Live feed of farmer queries and tips using Firestore Streams.
- **Persistent Auth**: Your session is saved automatically.

---
*Note: Images used in AI Detection and Community are currently handled via pickers; ensure you have camera/gallery permissions in your `AndroidManifest.xml` and `Info.plist`.*
